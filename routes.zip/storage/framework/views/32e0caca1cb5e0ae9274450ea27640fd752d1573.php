<?php $__env->startSection('title'); ?>
    Pricing
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row row-cols-1 row-cols-md-3 mb-3 text-center">
            <div class="col">
                <div class="card mb-4 rounded-3 shadow-sm" style="border-radius: 20px;">
                    
                    <div class="card-body">
                        <h1 class="card-title pricing-card-title">20$</h1>
                        <ul class="list-unstyled mt-3 mb-4">
                            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Voluptates, provident quisquam
                                dolorum vel omnis</p>
                            
                        </ul>
                        <button type="button" class="w-100 btn btn-lg btn-primary" style="border-radius: 25px;">buy</button>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card mb-4 rounded-3 shadow-sm" style="border-radius: 20px;">
                    
                    <div class="card-body">
                        <h1 class="card-title pricing-card-title">20$</h1>
                        <ul class="list-unstyled mt-3 mb-4">
                            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Voluptates, provident quisquam
                                dolorum vel omnis</p>
                            
                        </ul>
                        <button type="button" class="w-100 btn btn-lg btn-primary"
                            style="border-radius: 25px;">buy</button>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card mb-4 rounded-3 shadow-sm" style="border-radius: 20px;">
                    
                    <div class="card-body">
                        <h1 class="card-title pricing-card-title">20$</h1>
                        <ul class="list-unstyled mt-3 mb-4">
                            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Voluptates, provident quisquam
                                dolorum vel omnis</p>
                            
                        </ul>
                        <button type="button" class="w-100 btn btn-lg btn-primary"
                            style="border-radius: 25px;">buy</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.home_body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\muham\Desktop\Work\Laravel\Quiz-Project\resources\views/Home/pricing.blade.php ENDPATH**/ ?>