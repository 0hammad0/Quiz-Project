<?php $__env->startSection('title'); ?>
    Result
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="container p-5">
            <div class="card text-center">
                <div class="card-header">
                    <a href="<?php echo e(url('/')); ?>">
                        <i class="fas fa-times float-left" style="font-size: x-large"></i></a>
                    <?php echo e($series->name); ?>

                </div>
                <div class="card-body">
                    <h3>Little by little the bird takes the nest</h3>
                    <h4>Take flight now by subscribing to the License Pack</h4>
                    <h1><?php echo e($test->last_score); ?> correct out of <?php echo e($ques_count); ?></h1>
                    <div class="progress">
                        <div class="progress-bar progress-bar-striped bg-warning" role="progressbar"
                            style="width: <?php echo e(($test->last_score / $ques_count) * 100); ?>%"
                            aria-valuenow="<?php echo e(($test->last_score / $ques_count) * 100); ?>" aria-valuemin="0"
                            aria-valuemax="100"><?php echo e(($test->last_score / $ques_count) * 100); ?>%</div>
                    </div>
                    <hr />
                    <button class="btn btn-outline-success" onclick="fixes()">
                        Fixes
                    </button>
                    <button class="btn btn-outline-success" onclick="themes()">
                        Themes
                    </button>
                </div>
                <hr />
                <div class="container" id="fixes">
                    <div class="accordion" id="accordionExample">
                        <input type="hidden" value="<?php echo e($i = 1); ?>">
                        <?php $__currentLoopData = $final_res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fres): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($fres->result == 1): ?>
                                <div class="accordion-item   mb-2">
                                    <h2 class="accordion-header" id="heading<?php echo e($i); ?>">
                                        <button class="accordion-button acco-wd" type="button" data-bs-toggle="collapse"
                                            data-bs-target="#collapse<?php echo e($i); ?>" aria-expanded="true"
                                            aria-controls="collapse<?php echo e($i); ?>">
                                            <a type="button" class="series-btn"><i class="fas fa-check text-success"></i>
                                                &nbsp;Question <?php echo e($i); ?></a>
                                        </button>
                                    </h2>
                                    <div id="collapse<?php echo e($i); ?>" class="accordion-collapse collapse"
                                        aria-labelledby="heading<?php echo e($i); ?>" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <?php if($fres->file_path != null): ?>
                                                <img src="<?php echo e(asset($fres->file_path)); ?>" class="img-size">
                                            <?php endif; ?>
                                            <?php if($fres->video_path != null): ?>
                                                <video src="<?php echo e(asset($fres->video_path)); ?>" class="img-size"
                                                    type="video/mp4" controls></video>
                                            <?php endif; ?>
                                            <h4><?php echo e($fres->question); ?></h4>
                                            <h4>Your Answer: <?php echo e($fres->user_answer); ?></h4>
                                            <p><?php echo e($fres->ques_desc); ?></p>
                                        </div>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="heading<?php echo e($i); ?>">
                                        <button class="accordion-button acco-wd" type="button" data-bs-toggle="collapse"
                                            data-bs-target="#collapse<?php echo e($i); ?>" aria-expanded="true"
                                            aria-controls="collapse<?php echo e($i); ?>">
                                            <a type="button" class="series-btn"><i class="fas fa-times text-danger"></i>
                                                &nbsp;Question <?php echo e($i); ?></a>
                                        </button>
                                    </h2>
                                    <div id="collapse<?php echo e($i); ?>" class="accordion-collapse collapse"
                                        aria-labelledby="heading<?php echo e($i); ?>" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <?php if($fres->file_path != null): ?>
                                                <img src="<?php echo e(asset($fres->file_path)); ?>" class="img-size">
                                            <?php endif; ?>
                                            <?php if($fres->video_path != null): ?>
                                                <video src="<?php echo e(asset($fres->video_path)); ?>" class="img-size"
                                                    type="video/mp4" controls></video>
                                            <?php endif; ?>
                                            <h4><?php echo e($fres->question); ?></h4>
                                            <?php if($fres->question == 'E'): ?>
                                                <h4>Time out</h4>
                                            <?php else: ?>
                                                <h4>
                                                    <?php if($fres->user_answer == 'E'): ?>
                                                        Timed out
                                                    <?php else: ?>
                                                        Your Answer: <?php echo e($fres->user_answer); ?>

                                                    <?php endif; ?>
                                                </h4>
                                            <?php endif; ?>
                                            <p><?php echo e($fres->ques_desc); ?></p>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <input type="hidden" value="<?php echo e($i = $i + 1); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>


                <div class="container" id="themes" style="display: none;">

                    <?php if($t_security != '0'): ?>
                        <h4 class="float">Security &nbsp; <?php echo e($a_security); ?>/<?php echo e($t_security); ?></h4>
                        <div class="container mb-2">
                            <div class="progress" style="height: 10px;">
                                <div class="progress-bar" role="progressbar" aria-label="Example 20px high"
                                    style="width: <?php echo e(($a_security / $t_security) * 100); ?>%;" aria-valuenow="25"
                                    aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    <?php endif; ?>


                    <?php if($t_users != '0'): ?>
                        <h4 class="float">Users &nbsp; <?php echo e($a_users); ?>/<?php echo e($t_users); ?></h4>
                        <div class="container mb-2">
                            <div class="progress" style="height: 10px;">
                                <div class="progress-bar" role="progressbar" aria-label="Example 20px high"
                                    style="width: <?php echo e(($a_users / $t_users) * 100); ?>%;" aria-valuenow="25" aria-valuemin="0"
                                    aria-valuemax="100"></div>
                            </div>
                        </div>
                    <?php endif; ?>


                    <?php if($t_legislative != '0'): ?>
                        <h4 class="float">Legislative &nbsp; <?php echo e($a_legislative); ?>/<?php echo e($t_legislative); ?></h4>
                        <div class="container mb-2">
                            <div class="progress" style="height: 10px;">
                                <div class="progress-bar" role="progressbar" aria-label="Example 20px high"
                                    style="width: <?php echo e(($a_legislative / $t_legislative) * 100); ?>%;" aria-valuenow="25"
                                    aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if($t_cockpit != '0'): ?>
                        <h4 class="float">cockpit &nbsp; <?php echo e($a_cockpit); ?>/<?php echo e($t_cockpit); ?></h4>
                        <div class="container mb-2">
                            <div class="progress" style="height: 10px;">
                                <div class="progress-bar" role="progressbar" aria-label="Example 20px high"
                                    style="width: <?php echo e(($a_cockpit / $t_cockpit) * 100); ?>%;" aria-valuenow="25"
                                    aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if($t_various != '0'): ?>
                        <h4 class="float">various &nbsp; <?php echo e($a_various); ?>/<?php echo e($t_various); ?></h4>
                        <div class="container mb-2">
                            <div class="progress" style="height: 10px;">
                                <div class="progress-bar" role="progressbar" aria-label="Example 20px high"
                                    style="width:  <?php echo e(($a_various / $t_various) * 100); ?>%;" aria-valuenow="25"
                                    aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if($t_driver != '0'): ?>
                        <h4 class="float">various &nbsp; <?php echo e($a_driver); ?>/<?php echo e($t_driver); ?></h4>
                        <div class="container mb-2">
                            <div class="progress" style="height: 10px;">
                                <div class="progress-bar" role="progressbar" aria-label="Example 20px high"
                                    style="width:  <?php echo e(($a_driver / $t_driver) * 100); ?>%;" aria-valuenow="25"
                                    aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if($t_regulations != '0'): ?>
                        <h4 class="float">various &nbsp; <?php echo e($a_regulations); ?>/<?php echo e($t_regulations); ?></h4>
                        <div class="container mb-2">
                            <div class="progress" style="height: 10px;">
                                <div class="progress-bar" role="progressbar" aria-label="Example 20px high"
                                    style="width:  <?php echo e(($a_regulations / $t_regulations) * 100); ?>%;" aria-valuenow="25"
                                    aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if($t_mechanical != '0'): ?>
                        <h4 class="float">various &nbsp; <?php echo e($a_mechanical); ?>/<?php echo e($t_mechanical); ?></h4>
                        <div class="container mb-2">
                            <div class="progress" style="height: 10px;">
                                <div class="progress-bar" role="progressbar" aria-label="Example 20px high"
                                    style="width:  <?php echo e(($a_mechanical / $t_mechanical) * 100); ?>%;" aria-valuenow="25"
                                    aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if($t_ecology != '0'): ?>
                        <h4 class="float">various &nbsp; <?php echo e($a_ecology); ?>/<?php echo e($t_ecology); ?></h4>
                        <div class="container mb-2">
                            <div class="progress" style="height: 10px;">
                                <div class="progress-bar" role="progressbar" aria-label="Example 20px high"
                                    style="width:  <?php echo e(($a_ecology / $t_ecology) * 100); ?>%;" aria-valuenow="25"
                                    aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if($t_aids != '0'): ?>
                        <h4 class="float">various &nbsp; <?php echo e($a_aids); ?>/<?php echo e($t_aids); ?></h4>
                        <div class="container mb-2">
                            <div class="progress" style="height: 10px;">
                                <div class="progress-bar" role="progressbar" aria-label="Example 20px high"
                                    style="width:  <?php echo e(($a_aids / $t_aids) * 100); ?>%;" aria-valuenow="25"
                                    aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    <?php endif; ?>

                </div>
                <div class="container">
                    <div class="card-footer text-muted">
                        <button type="button" class="btn btn-danger doubt-btn" data-bs-toggle="modal"
                            data-bs-target="#exampleModal">
                            A doubt? <br /> Our expert can answer that
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <div class="container text-center">
            <button class="btn btn-warning sticky-bottom mb-5"><a href="/">Home</a></button>
        </div>

        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="container">
                            <h4>Spend the second</h4>
                            <h5>with our permit pack formula, an expert answers all your
                                questions
                            </h5>
                            <h4><b>Question about the License Pack?</b></h4>
                            <span>call 123 456 789</span>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-warning">Discover the license Pack</button>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('script'); ?>
        <script>
            function themes() {
                var a = document.getElementById("fixes");
                var b = document.getElementById("themes");
                a.style.display = "none";
                b.style.display = "block";
            }

            function fixes() {
                var a = document.getElementById("fixes");
                var b = document.getElementById("themes");
                a.style.display = "block";
                b.style.display = "none";
            }
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\muham\Desktop\Work\Laravel\Quiz-Project\resources\views/result.blade.php ENDPATH**/ ?>