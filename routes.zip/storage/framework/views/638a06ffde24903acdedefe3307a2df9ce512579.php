<?php $__env->startSection('title'); ?>
    Quiz
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="news_section layout_padding">
        <div class="container text-center">
            <h1 class="">Discovery series (10 questions)</h1>
            <div class="row row-cols-2" style="margin-bottom: 24px;">

                <?php $__currentLoopData = $disco; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($disc): ?>
                        <div class="col-md-6" style="padding-top: 5px">
                            <a href="<?php echo e(route('series.show', $disc)); ?>">
                                <button type="button" class="series-btn">
                                    <?php echo e($disc->name); ?> &nbsp;&nbsp;&nbsp;
                                    <i class="fas fa-arrow-circle-right float-end text-danger" style="font-size: 20px"></i>
                                </button>
                            </a>
                        </div>
                    <?php else: ?>
                        <h4>There are no series right now</h4>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="container text-center">
            <h1 class="">Classic series (40 questions)</h1>
            <div class="row row-cols-2">
                <?php $__currentLoopData = $classic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cla): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($cla): ?>
                        <div class="col-md-6" style="padding-top: 5px">
                            <a href="<?php echo e(route('series.show', $cla)); ?>">
                                <button type="button" class="series-btn">
                                    <?php echo e($cla->name); ?> &nbsp;&nbsp;&nbsp;
                                    <i class="fas fa-arrow-circle-right float-end text-danger" style="font-size: 20px"></i>
                                </button>
                            </a>
                        </div>
                    <?php else: ?>
                        <h4>There are no series right now.</h4>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\muham\Desktop\Work\Laravel\Quiz-Project\resources\views/Front/index.blade.php ENDPATH**/ ?>