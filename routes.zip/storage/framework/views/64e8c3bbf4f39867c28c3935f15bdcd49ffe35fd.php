<?php $__env->startSection('title'); ?>
    Buffer
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container buffer">
        <div class="container-fluid buffer-box">
            <div class="container pt-3 pb-3">
                <h1 class="text-center"><?php echo e($rec_name->name); ?></h1>

                <h3 class="text-center"><?php echo e($rec_name->series_type); ?> Series</h3>

                <div class="container text-center pt-4">
                    <a href="<?php echo e(route('question.show', $rec_name->id)); ?>"><i
                            class="fas fa-arrow-circle-right float-end text-warning" style="font-size: xxx-large"></i></a>
                </div>
                <div class="container text-center">
                    <div class="container">
                        <h3>Best Score: &nbsp; <?php echo e($rec->best_score); ?>/<?php echo e($ques_count); ?> </h3>
                        <h3>Completed Series: &nbsp; <?php echo e($rec->completed_series); ?> Times</h3>
                        <h3>Last Score: &nbsp; <?php echo e($rec->last_score); ?>/<?php echo e($ques_count); ?></h3>
                    </div>
                    <br />
                    <a class="btn btn-outline-warning" href="/result/<?php echo e($rec->id); ?>">last record</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\muham\Desktop\Work\Laravel\Quiz-Project\resources\views/Front/buffer.blade.php ENDPATH**/ ?>