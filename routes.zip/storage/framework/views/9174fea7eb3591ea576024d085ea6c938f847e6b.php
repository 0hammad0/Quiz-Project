<?php $__env->startSection('title'); ?>
    Buffer
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container buffer">
        <div class="container-fluid buffer-box">
            <div class="container pt-3 pb-3">
                <h1 class="text-center"><?php echo e($rec->name); ?></h1>

                <h3 class="text-center"><?php echo e($rec->series_type); ?> Series</h3>

                <div class="container text-center pt-4">
                    <a href="<?php echo e(route('question.show', $rec->id)); ?>"><i
                            class="fas fa-arrow-circle-right float-end text-warning" style="font-size: xxx-large">aro</i></a>
                </div>
                <div class="container text-center">
                    
                    <p>Stressed about starting your code reviews? </p>

                    <p> Embark in peace with these series of 10 easier questions 😎</p>
                    
                    
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\muham\Desktop\Work\Laravel\Quiz-Project\resources\views/Buffer_be.blade.php ENDPATH**/ ?>