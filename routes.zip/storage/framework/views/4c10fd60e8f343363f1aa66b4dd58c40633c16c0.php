<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Front end</title>
    <link rel="stylesheet" href="style.css" />
    <style>
        * {
            margin: 0;
            padding: 0;
        }

        .container-body {
            justify-content: center;
        }

        .container-header {
            background-color: rgb(16, 16, 87);
            border-radius: 1px;
            box-shadow: 2px 2px 2px rgb(16, 16, 87);
        }

        .container-header ul li {
            display: inline-block;
            padding: 22px;
            transition: 0.5s;
        }

        .container-header ul li:hover {
            background-color: rgb(42, 42, 92);
            border-radius: 25px;
        }

        .container-header ul li a {
            text-decoration: none;
            color: whitesmoke;
            font-family: sans-serif;
            transition: 0.5s;
        }

        .container-header ul li a:hover {
            color: rgb(175, 175, 240);
        }
    </style>
</head>

<body>
    <header>
        <div class="container-header">
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#">About Us</a></li>
                <li><a href="#">Servies</a></li>
                <li><a href="#">Contact Us</a></li>
            </ul>
        </div>
    </header>

    <body>
        <div class="container-body">
            <h1>Body</h1>
        </div>
    </body>
</body>

</html>
<?php /**PATH C:\Users\muham\Desktop\Work\Laravel\Quiz-Project\resources\views/adminPanel.blade.php ENDPATH**/ ?>