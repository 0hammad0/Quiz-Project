<?php $__env->startSection('title'); ?>
    Section Menu
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="news_section layout_padding">
        <div class="container text-center">
            <h1 class="">Entertainments au code</h1>
            <div class="row row-cols-2" style="margin-bottom: 24px;">
                <div class="col-md-6" style="padding-top: 5px">
                    <a href="<?php echo e(url('series-id-redirect', $seriesTypeID->id)); ?>">
                        <button type="button" class="series-btn q-btn">
                            Series Simples
                            <i class="fas fa-arrow-circle-right float-end text-danger" style="font-size: 20px"></i>
                        </button>
                    </a>
                </div>
                <div class="col-md-6" style="padding-top: 5px">
                    <a href="<?php echo e(url('series-id-redirect-examens', $seriesTypeID->id)); ?>">
                        <button type="button" class="series-btn q-btn">
                            Examens blancs
                            <i class="fas fa-arrow-circle-right float-end text-danger" style="font-size: 20px"></i>
                        </button>
                    </a>
                </div>
                <div class="col-md-6" style="padding-top: 5px">
                    <a href="">
                        <button type="button" class="series-btn q-btn">
                            Statistiques
                            <i class="fas fa-arrow-circle-right float-end text-danger" style="font-size: 20px"></i>
                        </button>
                    </a>
                </div>
                <div class="col-md-6" style="padding-top: 5px">
                    <a href="">
                        <button type="button" class="series-btn q-btn">
                            Mes erreurs
                            <i class="fas fa-arrow-circle-right float-end text-danger" style="font-size: 20px"></i>
                        </button>
                    </a>
                </div>
            </div>
        </div>
        <div class="container text-center">
            <h1 class="">Revisitions mes cours</h1>
            <div class="row row-cols-2" style="margin-bottom: 24px;">
                <div class="col-md-6" style="padding-top: 5px">
                    <a href="">
                        <button type="button" class="series-btn q-btn">
                            Articles
                            <i class="fas fa-arrow-circle-right float-end text-danger" style="font-size: 20px"></i>
                        </button>
                    </a>
                </div>
                <div class="col-md-6" style="padding-top: 5px">
                    <a href="">
                        <button type="button" class="series-btn q-btn">
                            Learning
                            <i class="fas fa-arrow-circle-right float-end text-danger" style="font-size: 20px"></i>
                        </button>
                    </a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.Home_body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\muham\Desktop\Work\Laravel\Quiz-Project\resources\views/Home/seriesMenu.blade.php ENDPATH**/ ?>