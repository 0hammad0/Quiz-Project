<?php $__env->startSection('title'); ?>
    Buffer
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container buffer">
        <div class="container-fluid buffer-box">
            <div class="container pt-3 pb-3">
                <h1 class="text-center"><?php echo e($disc->name); ?></h1>

                <?php if($disc->section == 1): ?>
                    <h3 class="text-center">Discovery Series</h3>
                <?php elseif($disc->section == 2): ?>
                    <h3 class="text-center">Classic Series</h3>
                <?php endif; ?>

                <div class="container text-center pt-4">
                    <a href="/discovery/<?php echo e($disc->id); ?>/question"><i
                            class="fas fa-arrow-circle-right float-end text-warning" style="font-size: xxx-large"></i></a>
                </div>
                <div class="container text-center">
                    <p>Stressed about starting your code reviews? </p>

                    <p> Embark in peace with these series of 10 easier questions</p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\muham\Desktop\Work\Laravel\Quiz-Project\resources\views/buffer_be.blade.php ENDPATH**/ ?>