<?php $__env->startSection('title'); ?>
    Question
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="container p-5">
            <div class="card text-center">
                <div class="card-header">
                    <a href="/">
                        <i class="fas fa-times float-left" style="font-size: x-large"></i></a>
                    <?php echo e($ser_qu->name); ?> - Question <?php echo e($ques_count); ?> of <?php echo e($total_ques); ?>

                    <?php if($que->audio_path != null): ?>
                        <i class="fas fa-play float-right" style="cursor: pointer" onclick="audio_play()" id="play"></i>
                        <i class="fas fa-pause float-right" style="cursor: pointer; display: none;" onclick="audio_pause()"
                            id="pause"></i>
                        <audio src="<?php echo e(asset($que->audio_path)); ?>" class="float-right" id="audio"></audio>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <?php if($que->file_path != null): ?>
                        <img src="<?php echo e(asset($que->file_path)); ?>" alt="question image" />
                    <?php endif; ?>
                    <?php if($que->video_path != null): ?>
                        <video src="<?php echo e(asset($que->video_path)); ?>" style="width: 100%" type="video/mp4" controls></video>
                    <?php endif; ?>
                    <hr />
                    <h4 id="question"><?php echo e($que->question); ?></h4>

                    <form action="<?php echo e(route('question.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="question_id" value="<?php echo e($que->id); ?>" />
                        <input type="hidden" name="series_id" value="<?php echo e($ser_qu->id); ?>" />
                        <input type="hidden" name="page_id" value="<?php echo e($ser_qu->id); ?>" />

                        <div class="container" id="question_set">

                            <div class="input-group mb-3">
                                <div class="input-group-text">
                                    <input type="checkbox" value="A"
                                        aria-label="Checkbox for following text input"id="op1" name="op1" />
                                </div>
                                <label for="op1" class="form-control ques-option"
                                    aria-label="Text input with checkbox"><?php echo e($que->option1); ?></label>
                            </div>

                            <div class="input-group mb-3">
                                <div class="input-group-text">
                                    <input type="checkbox" value="B"
                                        aria-label="Checkbox for following text input"id="op2" name="op2" />
                                </div>
                                <label for="op2" class="form-control ques-option"
                                    aria-label="Text input with checkbox"><?php echo e($que->option2); ?></label>
                            </div>

                            <?php if($que->option3): ?>
                                <div class="input-group mb-3">
                                    <div class="input-group-text">
                                        <input type="checkbox" value="C"
                                            aria-label="Checkbox for following text input"id="op3" name="op3" />
                                    </div>
                                    <label for="op3" class="form-control ques-option"
                                        aria-label="Text input with checkbox"><?php echo e($que->option3); ?></label>
                                </div>
                            <?php endif; ?>

                            <?php if($que->option4): ?>
                                <div class="input-group mb-3">
                                    <div class="input-group-text">
                                        <input type="checkbox" value="D"
                                            aria-label="Checkbox for following text input"id="op4" name="op4" />
                                    </div>
                                    <label for="op4" class="form-control ques-option"
                                        aria-label="Text input with checkbox"><?php echo e($que->option4); ?></label>
                                </div>
                            <?php endif; ?>
                        </div>
                        <h3 id="ans_show"></h3>
                        <p id="desc" style="display: none"><?php echo e($que->description); ?></p>
                        <hr id="hr" style="display: none">
                        <h4 id="correct_answer" style="display: none">Correct Answer: <?php echo e($que->answer); ?></h4>
                        <h1 style="display: none" id="ans"><?php echo e($que->answer); ?></h1>
                </div>
                <div class="card-footer text-muted"
                    style="    justify-content: center;
                                display: flex;">
                    <a class="btn btn-danger" style="color: white" onclick="validate()" id="validate">Validate</a>


                    <button type="submit" class="btn btn-success" style="color: white; display: none"
                        id="continue">Continue</button>
                </div>

                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\muham\Desktop\Work\Laravel\Quiz-Project\resources\views/question.blade.php ENDPATH**/ ?>