<?php echo e($slot); ?>

<?php /**PATH C:\Users\muham\Desktop\Work\Laravel\Quiz-Project\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>