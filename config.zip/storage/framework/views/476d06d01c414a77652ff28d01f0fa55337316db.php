<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="viewport" content="initial-scale=1, maximum-scale=1" />
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('asset/images/logo.png')); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.0.0-beta.2.4/assets/owl.carousel.min.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/css/style.css')); ?>" />
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" />
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700|Poppins:400,700&display=swap"
        rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css"
        media="screen" />
    <script src="https://kit.fontawesome.com/cfa23f9428.js" crossorigin="anonymous"></script>
</head>

<body style="background-color: rgb(216, 231, 255)">
    <!--header section start -->
    <div class="header_bg"
        style="
                box-shadow: 1px 0px 15px 0px black;
                background-color: rgb(253, 255, 252);
            ">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <a href="/" class="logo" style="font-size: 25px">Take a Quiz</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="/index">Traffic Laws</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Driver's license</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Our Cars</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Assistance</a>
                        </li>
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item ml-4">
                                <?php if(Route::has('login')): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                            </li>
                        <?php else: ?>
                            <li class="nav-item">
                                <a id="navbar" class="nav-link" href="#" role="button" aria-haspopup="true"
                                    aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                            </li>
                            <li>
                                <div class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                                        onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </nav>
        </div>
    </div>

    <?php echo $__env->yieldContent('content'); ?>

    <script src="<?php echo e(asset('asset/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/js/jquery-3.0.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/js/plugin.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/js/jquery.mCustomScrollbar.concat.min.j')); ?>s"></script>
    <script src="<?php echo e(asset('asset/js/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/js/owl.carousel.js')); ?>"></script>
    <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"
        integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous">
    </script>

    <script>
        function validate() {
            var a = document.getElementById("question_set");
            var b = document.getElementById("validate");
            var c = document.getElementById("continue");
            var d = document.getElementById("desc");
            var e = document.getElementById("question");
            var f = document.getElementById("correct_answer");
            var g = document.getElementById("hr");

            var ca1 = document.getElementById("op1");
            var ca2 = document.getElementById("op2");

            if (document.getElementById("op3")) {
                var ca3 = document.getElementById("op3");

                if (ca3.checked == true) {
                    var c3 = ca3.value;
                }
            }

            if (document.getElementById("op4")) {
                var ca4 = document.getElementById("op4");

                if (ca4.checked == true) {
                    var c4 = ca4.value;
                }
            }

            if (ca1.checked == true || ca2.checked == true || ca3.checked == true || ca4.checked == true) {

                a.style.display = "none";
                b.style.display = "none";
                c.style.display = "block";
                d.style.display = "block";
                e.style.display = "none";
                f.style.display = "block";
                g.style.display = "block";

                if (ca1.checked == true)
                    var c1 = ca1.value;

                if (ca2.checked == true)
                    var c2 = ca2.value;

                if (c1 == undefined)
                    c1 = "";

                if (c2 == undefined)
                    c2 = "";

                if (c3 == undefined)
                    c3 = "";

                if (c4 == undefined)
                    c4 = "";

                var result = "";
                result = c1 + c2 +
                    c3 + c4;


                var ans = document.getElementById("ans");
                var ans_show = document.getElementById("ans_show");

                if (result == ans.textContent)
                    ans_show.innerHTML = "Your answer is True";
                else
                    ans_show.innerHTML = "Your answer is false";
            }
        }

        function audio_play() {
            var play = document.getElementById("play");
            var pause = document.getElementById("pause");
            var audio = document.getElementById("audio");

            play.style.display = "none";
            pause.style.display = "block";
            audio.play();
        }

        function audio_pause() {
            var play = document.getElementById("play");
            var pause = document.getElementById("pause");
            var audio = document.getElementById("audio");

            play.style.display = "block";
            pause.style.display = "none";
            audio.pause();
            audio.currentTime = 0;
        }
    </script>
    <?php echo $__env->yieldContent('script'); ?>
</body>

</html>
<?php /**PATH C:\Users\muham\Desktop\Work\Laravel\Quiz-Project\resources\views/layouts/frontend/body.blade.php ENDPATH**/ ?>